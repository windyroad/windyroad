<?php

header('Content-type: text/css'); 

$path = dirname( $_SERVER[ 'SCRIPT_NAME' ] );

?>
/* Vistered Little Theme CSS file. */

/* Flexible Default theme. IE fixes */
@import url('common-ie.css.php?skin=default-light');

#header{
	width: expression(Math.max( 800, document.documentElement.offsetWidth-20 ) + 'px');	
}

#bodyowner
{
	width: expression(Math.min( 1200, Math.max( 800, document.documentElement.offsetWidth-200 ) ) + 'px'); 
}

#contentcontainer
{
	padding-top: 10px;
	margin-right: 0px;
	padding-right: 233px;
}

.blogbefore .middle, 
.blogafter .middle
{
	margin: 0px; 
}

.blogbefore .middle, 
.blogafter .middle
{
	background: none;
	filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(enabled=true, src=<?php echo $path; ?>/default-light-flex/middle.png, sizingMethod=scale);
}


.blogbefore .left, .blogbefore .right,
.blogafter .left, .blogafter .right
{
	margin-bottom: 0px; 
}

.blogbefore .left,
.blogafter .left
{
	margin-right: -3px;
	background: none;
	filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(enabled=true, src=<?php echo $path; ?>/default-light-flex/left.png, sizingMethod=scale);
}

.blogbefore .right,
.blogafter .right
{
	margin-left: -3px;
	background: none;
	filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(enabled=true, src=<?php echo $path; ?>/default-light-flex/right.png, sizingMethod=scale);
}

.blog
{
	height: expression(this.clientHeight + 'px');
}

.blog
{
	background: none;
	filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(enabled=true, src=<?php echo $path; ?>/default-light-flex/background.png, sizingMethod=scale);
}
